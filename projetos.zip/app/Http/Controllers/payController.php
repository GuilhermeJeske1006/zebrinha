<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use PagSeguro\Configuration\Configure;

class payController extends Controller
{
   
}
