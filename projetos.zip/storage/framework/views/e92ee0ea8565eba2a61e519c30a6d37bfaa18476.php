
<?php $__env->startComponent('components.topWhite', ['carrinho' => $carrinho]); ?><?php echo $__env->renderComponent(); ?>

<?php $__env->startSection('body'); ?>
    <?php $__env->startComponent('Home.index', ["lista" => $lista]); ?><?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\email\Desktop\projetos\resources\views/index.blade.php ENDPATH**/ ?>