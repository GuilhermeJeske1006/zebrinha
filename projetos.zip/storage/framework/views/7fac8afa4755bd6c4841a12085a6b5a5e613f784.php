<?php $__currentLoopData = $lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item women">
    <!-- Block2 -->
    <div class="block2">
        <div class="block2-pic hov-img0">
            <img src="<?php echo e(asset($prod->foto)); ?>" alt="IMG-PRODUCT">

            <a href="<?php echo e(route('details',  [$prod->id])); ?>" data-value="<?php echo e($prod->id); ?>" class="block2-btn flex-c-m stext-103 cl2 size-102 bg0 bor2 hov-btn1 p-lr-15 trans-04 ">
                Adicionar
            </a>
        </div>
        <?php $__env->startComponent('components.modalDetails',['prod' => $prod, 'id' => $prod->id] ); ?><?php echo $__env->renderComponent(); ?>

        <div class="block2-txt flex-w flex-t p-t-14">
            <div class="block2-txt-child1 flex-col-l ">
                <a href="<?php echo e(route('details',  [$prod->id])); ?>" class="stext-104 cl4 hov-cl1 trans-04 js-name-b2 p-b-6">
                    <?php echo e($prod->nome); ?>

                </a>

                <span class="stext-105 cl3">
					<b>R$<?php echo e($prod->valor); ?></b>
				</span>
            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\email\Desktop\projetos\resources\views/components/card.blade.php ENDPATH**/ ?>