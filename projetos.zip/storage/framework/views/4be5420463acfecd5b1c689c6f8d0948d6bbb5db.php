<div class="wrap-header-cart js-panel-cart">
    <div class="s-full js-hide-cart"></div>

    <div class="header-cart flex-col-l p-l-65 p-r-25">
        <div class="header-cart-title flex-w flex-sb-m p-b-8">
				<span class="mtext-103 cl2">
					Seu carrinho
				</span>

            <div class="fs-35 lh-10 cl2 p-lr-5 pointer hov-cl1 trans-04 js-hide-cart">
                <i class="zmdi zmdi-close"></i>
            </div>
        </div>

        <?php $total = 0; ?>
        <div class="header-cart-content flex-w js-pscroll">
            <?php if(isset($carrinho) && count($carrinho) > 0): ?>
            <ul class="header-cart-wrapitem w-full">
                <?php $__currentLoopData = $carrinho; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indice => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li class="header-cart-item flex-w flex-t m-b-12">
                    <div class="header-cart-item-img">
                        <img src="<?php echo e(asset($cart->attributes->foto)); ?>" alt="IMG">
                    </div>

                    <div class="header-cart-item-txt p-t-8">
                        <a href="<?php echo e(route('details',  [$cart->id])); ?>" class="header-cart-item-name m-b-18 hov-cl1 trans-04">
                            <?php echo e($cart->name); ?>

                        </a>
                        <div class="d-flex">
                            <span class="header-cart-item-info">
								<?php echo e($cart->quantity); ?> x R$<?php echo e($cart->price); ?>

							</span>
                            <form action="<?php echo e(route('excluir_carrinho')); ?>" method="POST" style="margin-left: 50%;">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($cart->id); ?>" name="id">
                            <button type="submit" class="header-cart-item-info" style="margin-left: 50%;">
                                <i class="fa fa-trash-o"></i>
							</button>
                            </form>
                        </div>


                    </div>
                </li>
                    <?php $total += $cart->price * $cart->quantity ; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <div class="container">
                    <div class="row">
                        <h5 style="text-align: center"><b>Nenhum item encontrado no carrinho.</b></h5>

                    </div>
                </div>
            <?php endif; ?>

            <div class="w-full">
                <div class="header-cart-total w-full p-tb-40">
                    Total: R$ <?php echo e($total); ?>

                </div>

                <div class="header-cart-buttons flex-w w-full">
                    <a href="<?php echo e(route('checkout')); ?>" class="flex-c-m stext-101 cl0 size-107 bg3 bor2 hov-btn3 p-lr-15 trans-04 m-r-8 m-b-10">
                        Finalizar carrinho
                    </a>

                </div>
            </div>
        </div>
    </div>
</div>




<?php /**PATH C:\Users\email\Desktop\projetos\resources\views/home/Cart.blade.php ENDPATH**/ ?>