<?php if($paginator->hasPages()): ?>

















    <div class="flex-c-m flex-w w-full p-t-45">
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="flex-c-m stext-101 cl5 size-103 bg2 bor1 hov-btn1 p-lr-15 trans-04">
                Ver mais
            </a>
        <?php else: ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class=" disabled flex-c-m stext-101 cl5 size-103 bg2 bor1 hov-btn1 p-lr-15 trans-04">
                Ver mais
            </a>
        <?php endif; ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\email\Desktop\projetos\resources\views/vendor/pagination/simple-default.blade.php ENDPATH**/ ?>