<?php return array (
  'pay-modal' => 'App\\Http\\Livewire\\PayModal',
);